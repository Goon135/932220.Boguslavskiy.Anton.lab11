using System.Diagnostics;
using Calculatornew.Models;
using Microsoft.AspNetCore.Mvc;

namespace Calculatornew.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult ManualParsingSingleAction()
        {
            return View();
        }

        public IActionResult ManualParsingSeparateActions()
        {
            return View();
        }

        public IActionResult ModelBindingParameters()
        {
            return View();
        }

        public IActionResult ModelBindingSeparateModel()
        {
            return View();
        }
        [HttpPost]
        public IActionResult ManualParsingSingleAction(string number1, string number2, string operation)
        {
            double num1 = double.Parse(number1);
            double num2 = double.Parse(number2);
            try
            {
                double result = PerformCalculation(num1, num2, operation);

                ViewBag.resultMessage = $"{num1} {operation} {num2} = {result}";
            }
            catch (DivideByZeroException) 
            {
                ViewBag.resultMessage = "������: ������� �� ���� ����������.";
            }
            catch (InvalidOperationException ex)
            {
                ViewBag.resultMessage = $"������: {ex.Message}";
            }
            return View("result");
        }

        [HttpPost]
        public IActionResult ManualParsingSeparateActions(string number1, string number2, string operation)
        {
            double num1 = double.Parse(number1);
            double num2 = double.Parse(number2);
            try
            {
                double result = PerformCalculation(num1, num2, operation);

                ViewBag.resultMessage = $"{num1} {operation} {num2} = {result}";
            }
            catch (DivideByZeroException)
            {
                ViewBag.resultMessage = "������: ������� �� ���� ����������.";
            }
            catch (InvalidOperationException ex)
            {
                ViewBag.resultMessage = $"������: {ex.Message}";
            }
            return View("result");
        }


        [HttpPost]
        public IActionResult ModelBindingParameters(double number1, double number2, string operation)
        {
            try
            {
                double result = PerformCalculation(number1, number2, operation);
                ViewBag.resultMessage = $"{number1} {operation} {number2} = {result}";
            }
            catch (DivideByZeroException)
            {
                ViewBag.resultMessage = "������: ������� �� ���� ����������.";
            }
            catch (InvalidOperationException ex)
            {
                ViewBag.resultMessage = $"������: {ex.Message}";
            }
            return View("result");
        }


        [HttpPost]
        public IActionResult ModelBindingSeparateModel(CalculationModel model)
        {
            try
            {
                double result = PerformCalculation(model.Number1, model.Number2, model.Operation);
                ViewBag.resultMessage = $"{model.Number1} {model.Operation} {model.Number2} = {result}";
            }
            catch (DivideByZeroException)
            {
                ViewBag.resultMessage = "������: ������� �� ���� ����������.";
            }
            catch (InvalidOperationException ex)
            {
                ViewBag.resultMessage = $"������: {ex.Message}";
            }
            return View("result");
        }

        private double PerformCalculation(double number1, double number2, string operation)
        {
            return operation switch
            {
                "+" => number1 + number2,
                "-" => number1 - number2,
                "*" => number1 * number2,
                "/" when number2 != 0 => number1 / number2,
                "/" => throw new DivideByZeroException("������ ������ �� ����"),
                _ => throw new InvalidOperationException("�������� ��������"),
            };
        }
    }
}
